package atlassianJira;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.JiraRestClientFactory;
import com.atlassian.jira.rest.client.api.domain.SearchResult;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.atlassian.util.concurrent.Promise;

import java.net.URI;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import org.apache.commons.httpclient.util.URIUtil;

import configuration.ByPassCert;
import configuration.DisplayFields;
import configuration.ExcelReader;
import configuration.ExcelWriter;

/**
 * Entry-point invoked when the jar is executed.
 */
public class Main extends ExcelReader {

	private static final String JIRA_URL = "https://dishademo.atlassian.net";
	//private static final String JIRA_URL="https://atlassian.metrobank.plc.uk";

	// private static final String JIRA_ADMIN_USERNAME = "dishashetty021@gmail.com";
	// private static final String JIRA_ADMIN_PASSWORD = "Ready2go88";
	public static void main(String[] args) throws Exception {

		ExcelReader ER = new ExcelReader();
		String userData[] = ER.getUserData();
		final String JIRA_ADMIN_USERNAME = userData[0];
		final String JIRA_ADMIN_PASSWORD = userData[1];
		DateFormat dateFormat = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		DisplayFields CDTJ = new DisplayFields();
		StringBuilder intro = new StringBuilder();
		intro.append(
				"**********************************************************************************************\r\n");
		intro.append("*                               Jira URL:  " + JIRA_URL + "                   *\r\n");
		intro.append(
				"**********************************************************************************************\r\n");
		System.out.println(intro.toString());
		
		// Construct the JRJC client
		System.out.println(String.format("Logging in to %s with username '%s' and password '%s'", JIRA_URL,
				JIRA_ADMIN_USERNAME, JIRA_ADMIN_PASSWORD));
		JiraRestClientFactory factory = new AsynchronousJiraRestClientFactory();
		URI uri = new URI(JIRA_URL);
		JiraRestClient client = factory.createWithBasicHttpAuthentication(uri, JIRA_ADMIN_USERNAME,
				JIRA_ADMIN_PASSWORD);

		// Invoke the JRJC Client
		String JQL = ER.getJQuery();
		Promise<SearchResult> searchJqlPromise = client.getSearchClient().searchJql(JQL);

		String fieldsData[] = ER.getDesiredColumns();
		String desiredColumn = fieldsData[0];
		String desiredFields = fieldsData[1];

		int i = 0;
		switch (desiredColumn) {
		case "Custom":
			i = 1;
			if (desiredFields.contains("Project")) {
				CDTJ.getProject(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("IssueType")) {
				CDTJ.getIssueType(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Key")) {
				CDTJ.getKey(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Summary")) {
				CDTJ.getSummary(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Status")) {
				CDTJ.getStatus(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Priority")) {
				CDTJ.getPriority(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Assignee")) {
				CDTJ.getAssignee(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Description")) {
				CDTJ.getDescription(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("CreationDate")) {
				CDTJ.getCreationDate(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("UdateDate")) {
				CDTJ.getUpdateDate(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("AffectedVersion")) {
				CDTJ.getAffectedVersion(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Comments")) {
				// CDTJ.getComments(searchJqlPromise, date1 , i++);
			}
			if (desiredFields.contains("Components")) {
				CDTJ.getComponents(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("DueDate")) {
				// CDTJ.getDueDate(searchJqlPromise, date1 , i++);
			}
			if (desiredFields.contains("FixVersions")) {
				CDTJ.getFixVersions(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("IssueLinks")) {
				CDTJ.getIssueLinks(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Labels")) {
				// CDTJ.getLabels(searchJqlPromise, date1 , i++);
			}
			if (desiredFields.contains("Reporter")) {
				CDTJ.getReporter(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("SubTasks")) {
				// CDTJ.getSubTasks(searchJqlPromise, date1 , i++);
			}
			if (desiredFields.contains("Votes")) {
				CDTJ.getVotes(searchJqlPromise, date1, i++);
			}
			if (desiredFields.contains("Worklogs")) {
				CDTJ.getWorklogs(searchJqlPromise, date1, i++);
			}	

			break;
			
		case "All":
			i = 1;
			CDTJ.getProject(searchJqlPromise, date1, i++);
			CDTJ.getIssueType(searchJqlPromise, date1, i++);
			CDTJ.getKey(searchJqlPromise, date1, i++);
			CDTJ.getSummary(searchJqlPromise, date1, i++);
			CDTJ.getStatus(searchJqlPromise, date1, i++);
			CDTJ.getPriority(searchJqlPromise, date1, i++);
			CDTJ.getAssignee(searchJqlPromise, date1, i++);
			CDTJ.getDescription(searchJqlPromise, date1, i++);
			CDTJ.getCreationDate(searchJqlPromise, date1, i++);
			CDTJ.getUpdateDate(searchJqlPromise, date1, i++);
			CDTJ.getAffectedVersion(searchJqlPromise, date1, i++);
			// CDTJ.getComments(searchJqlPromise, date1 , i++);
			CDTJ.getComponents(searchJqlPromise, date1, i++);
			// CDTJ.getDueDate(searchJqlPromise, date1 , i++);
			CDTJ.getFixVersions(searchJqlPromise, date1, i++);
			CDTJ.getIssueLinks(searchJqlPromise, date1, i++);
			// CDTJ.getLabels(searchJqlPromise, date1 , i++);
			CDTJ.getReporter(searchJqlPromise, date1, i++);
			// CDTJ.getSubTasks(searchJqlPromise, date1 , i++);
			CDTJ.getVotes(searchJqlPromise, date1, i++);
			CDTJ.getWorklogs(searchJqlPromise, date1, i++);		
			
			break;		

		default:
			System.out.println("Invalid Input");	
		
			break;
		}
		System.out.println("Successful. Now exiting.");
		System.exit(0);
	}
	// https://docs.atlassian.com/software/jira/docs/api/7.1.2/com/atlassian/jira/issue/Issue.html?_ga=2.185880297.1900774284.1539088717-1003429601.1539088717
}
// project = DISHADEMOPROJECT AND status in ("To Do" ) ORDER BY assignee ,
// resolutiondate
