package configuration;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class ExcelReader {
	
	public String getJQuery() throws Exception {
		FileInputStream fis = new FileInputStream("D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\dataSheet.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet JQL = workbook.getSheet("JQL");
		Row jqueryrow = JQL.getRow(1);
		
		Cell jquerycell = jqueryrow.getCell(0);
		String jQueryString = jquerycell.getStringCellValue();
		
		fis.close();
		workbook.close();
		return jQueryString;
	}
	public  String[] getUserData() throws Exception {
		FileInputStream fis = new FileInputStream("D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\dataSheet.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet JQL = workbook.getSheet("JQL");
		Row jqueryrow = JQL.getRow(1);
		Cell usernamecell = jqueryrow.getCell(1);
		 final String usernameString = usernamecell.getStringCellValue();
		
		Cell passwordcell = jqueryrow.getCell(2);
		 final String passwordString = passwordcell.getStringCellValue();
	
		 String userData[] = {usernameString, passwordString};
		
		fis.close();
		workbook.close();
		return userData;
	}
	public String[] getDesiredColumns() throws Exception {
		FileInputStream fis = new FileInputStream("D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\dataSheet.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet JQL = workbook.getSheet("JQL");
		Row jqueryrow = JQL.getRow(1);	
		Cell desiredColumnsCell = jqueryrow.getCell(3);
		String desiredColumns = desiredColumnsCell.getStringCellValue();
		
		Row getDesiredFields = JQL.getRow(3);
		Cell desiredColumnsKeywordsCell = getDesiredFields.getCell(3);
		String desiredColumnsKeywords = desiredColumnsKeywordsCell.getStringCellValue();
		
		String fieldsData[] = {desiredColumns , desiredColumnsKeywords};
		
		fis.close();
		workbook.close();
		return fieldsData;
	}

}