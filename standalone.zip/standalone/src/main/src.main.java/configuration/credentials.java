package configuration;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Properties;

public class credentials {
	public static Properties prop = new Properties();
	public static String filepath;

	/*Method used to fetch the data from the credentials file*/
	public static String getPropertyValue(String key) {
		return prop.getProperty(key);
	}

}
