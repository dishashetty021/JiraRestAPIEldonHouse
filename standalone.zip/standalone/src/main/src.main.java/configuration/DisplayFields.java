package configuration;

import java.io.Serializable;
import java.util.Iterator;
import org.joda.time.DateTime;
import org.joda.time.ReadableDateTime;
import org.joda.time.ReadableInstant;
import org.joda.time.base.AbstractDateTime;
import org.joda.time.base.AbstractInstant;
import org.joda.time.base.BaseDateTime;

import com.atlassian.jira.rest.client.api.AddressableEntity;
import com.atlassian.jira.rest.client.api.domain.BasicComponent;
import com.atlassian.jira.rest.client.api.domain.BasicPriority;
import com.atlassian.jira.rest.client.api.domain.BasicProject;
import com.atlassian.jira.rest.client.api.domain.BasicStatus;
import com.atlassian.jira.rest.client.api.domain.BasicUser;
import com.atlassian.jira.rest.client.api.domain.BasicVotes;
import com.atlassian.jira.rest.client.api.domain.Comment;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.api.domain.IssueLink;
import com.atlassian.jira.rest.client.api.domain.SearchResult;
import com.atlassian.jira.rest.client.api.domain.Subtask;
import com.atlassian.jira.rest.client.api.domain.User;
import com.atlassian.jira.rest.client.api.domain.Version;
import com.atlassian.jira.rest.client.api.domain.Worklog;
import com.atlassian.util.concurrent.Promise;

public class DisplayFields {
	int printedTimes = 0;

	public void getDescription(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			String printOutput = issue.getDescription();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			System.out.println(rowNo);
			EW.printToExcel(printOutput, rowNo, date1, "Description", printedTimes, i);

		}
	}

	public void getSummary(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			String printOutput = issue.getSummary();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Summary", printedTimes, i);
		}
	}

	public void getCreationDate(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			DateTime dateTime = issue.getCreationDate();
			String printOutput = dateTime.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "CreationDate", printedTimes, i);
		}
	}

	public void getAffectedVersion(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<Version> iterableVersion = issue.getAffectedVersions();
			String printOutput = iterableVersion.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "AffectedVersion", printedTimes, i);
		}
	}

	public void getPriority(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			BasicPriority priority = issue.getPriority();
			String longTextPrintOutput = priority.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("name") + 5);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Priority", printedTimes, i);
		}
	}

	public void getStatus(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			BasicStatus status = issue.getStatus();
			String longTextPrintOutput = status.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("name") + 5);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Status", printedTimes, i);
		}
	}

	public void getKey(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			String assignee = issue.getKey();
			String printOutput = assignee.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Key", printedTimes, i);
		}
	}

	public void getAssignee(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			BasicUser assignee = issue.getAssignee();
			String longTextPrintOutput = assignee.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("displayName") + 12);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Assignee", printedTimes, i);
		}
	}

	public void getComments(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<Comment> comments = issue.getComments();
			int firstCount = 0;
			Iterator<Comment> it = comments.iterator();
			int copyRow = 0;
			while (it.hasNext()) {
				Comment comentprint = it.next();
				String printOutput = comentprint.toString();
				System.out.println(printOutput);
				printedTimes = printedTimes + 1;
				firstCount = firstCount + 1;
				rowNo = rowNo + 1;

				while (firstCount == 1) {
					copyRow = rowNo;
				}

				EW.printToExcel(printOutput, copyRow, date1, "Comments", printedTimes, i);
			}
		}
	}

	public void getComponents(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<BasicComponent> components = issue.getComponents();
			String printOutput = components.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Components", printedTimes, i);
		}
	}

	public void getDueDate(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			DateTime dueDate = issue.getDueDate();
			String printOutput = dueDate.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "DueDate", printedTimes, i);
		}
	}

	public void getFixVersions(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<Version> fixVersions = issue.getFixVersions();
			String printOutput = fixVersions.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "FixVersion", printedTimes, i);
		}
	}

	public void getIssueLinks(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<IssueLink> issueLinks = issue.getIssueLinks();
			String longTextPrintOutput = issueLinks.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("targetIssueKey") + 15);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput1 = part1.substring(0, indexOfChar);
			String part2 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("description") + 12);

			if (part2.contains(",")) {
				indexOfChar = part2.indexOf(',');
			} else {
				indexOfChar = part2.indexOf('}');
			}
			String printOutput2 = part2.substring(0, indexOfChar);
			String printOutput = printOutput2 + " --> " + printOutput1;

			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "IssueLinks", printedTimes, i);
		}
	}

	public void getIssueType(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			AddressableEntity issueType = issue.getIssueType();
			String longTextPrintOutput = issueType.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("name") + 5);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);

			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "IssueType", printedTimes, i);
		}
	}

	public void getLabels(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		int firstCount = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<String> labels = issue.getLabels();
			Iterator<String> it = labels.iterator();
			int copyRow = 0;
			while (it.hasNext()) {
				String printOutput = it.next();
				System.out.println(printOutput);
				printedTimes = printedTimes + 1;
				firstCount = firstCount + 1;
				rowNo = rowNo + 1;

				while (firstCount == 1) {
					copyRow = rowNo;
				}

				EW.printToExcel(printOutput, copyRow, date1, "Labels", printedTimes, i);
			}
		}
	}

	public void getProject(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			BasicProject project = issue.getProject();
			String longTextPrintOutput = project.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("name") + 5);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);

			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Project", printedTimes, i);
		}
	}

	public void getReporter(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			User reporter = issue.getReporter();
			String longTextPrintOutput = reporter.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("displayName") + 12);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);

			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Reporter", printedTimes, i);
		}
	}

	public void getSubTasks(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<Subtask> subtasks = issue.getSubtasks();
			int firstCount = 0;
			Iterator<Subtask> it = subtasks.iterator();
			int copyRow = 0;
			while (it.hasNext()) {
				Subtask subtaskprint = it.next();
				String printOutput = subtaskprint.toString();
				System.out.println(printOutput);
				printedTimes = printedTimes + 1;
				firstCount = firstCount + 1;
				rowNo = rowNo + 1;

				while (firstCount == 1) {
					copyRow = rowNo;
				}

				EW.printToExcel(printOutput, copyRow, date1, "Subtasks", printedTimes, i);
			}
		}
	}

	public void getUpdateDate(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			DateTime updateDate = issue.getUpdateDate();
			String printOutput = updateDate.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "UpdateDate", printedTimes, i);
		}
	}

	public void getVotes(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			BasicVotes votes = issue.getVotes();
			String longTextPrintOutput = votes.toString();
			String part1 = longTextPrintOutput.substring(longTextPrintOutput.indexOf("votes=") + 6);
			int indexOfChar = 0;
			if (part1.contains(",")) {
				indexOfChar = part1.indexOf(',');
			} else {
				indexOfChar = part1.indexOf('}');
			}
			String printOutput = part1.substring(0, indexOfChar);

			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "Votes", printedTimes, i);
		}
	}

	public void getWorklogs(Promise<SearchResult> searchJqlPromise, String date1, int i) throws Exception {
		ExcelWriter EW = new ExcelWriter();
		int rowNo = 0;
		for (Issue issue : searchJqlPromise.claim().getIssues()) {
			Iterable<Worklog> worklog = issue.getWorklogs();
			String printOutput = worklog.toString();
			System.out.println(printOutput);
			rowNo = rowNo + 1;
			printedTimes = printedTimes + 1;
			EW.printToExcel(printOutput, rowNo, date1, "WorkLogs", printedTimes, i);
		}
	}

}