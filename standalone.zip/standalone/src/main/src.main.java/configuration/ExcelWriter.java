package configuration;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import atlassianJira.Main;

public class ExcelWriter extends Main {

	public void printToExcel(String result, int rowNo, String date1, String headerText, int printedTimes, int cellNo)
			throws Exception {
		String path;
		if (printedTimes == 1)
			path = "D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\dataSheet.xlsx";
		else
			path = "D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\JiraResultSheet"+ date1 + ".xlsx";
		FileInputStream fis = new FileInputStream(path);
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		Sheet resultSheet = workbook.getSheet("Result");
		// CellStyle style2 = workbook.createCellStyle(); // Create new style
		// Set wordwrap

		Row headerRow = resultSheet.getRow(0);
		Cell headerCell = headerRow.createCell(cellNo);
		headerCell.setCellValue(headerText);
		Cell serialHeader = headerRow.createCell(0);
		serialHeader.setCellValue("SerialNo");
		Row resultRow = resultSheet.getRow(rowNo);
		Cell serialNo = resultRow.createCell(0);
		serialNo.setCellValue(rowNo);

		Cell resultCell = resultRow.createCell(cellNo);
		resultCell.setCellValue(result);
		resultSheet.autoSizeColumn(cellNo);
		/*--------------------BOLD , CENTER , BORDER ----------------*/
		XSSFCellStyle style = workbook.createCellStyle();
		style.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
		style.setFillPattern(FillPatternType.FINE_DOTS);
		XSSFFont font = workbook.createFont();
		font.setFontHeightInPoints((short) 12);
		font.setBold(true);
		style.setFont(font);
		style.setBorderTop(BorderStyle.THICK);
		style.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderBottom(BorderStyle.THICK);
		style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderRight(BorderStyle.THICK);
		style.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style.setBorderLeft(BorderStyle.THICK);
		style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style.setWrapText(true);
		style.setAlignment(HorizontalAlignment.CENTER);
		style.setVerticalAlignment(VerticalAlignment.CENTER);

		/*----------------------------- CENTER , BORDER ----------------*/
		XSSFCellStyle style2 = workbook.createCellStyle();
		style2.setBorderTop(BorderStyle.MEDIUM_DASHED);
		style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
		style2.setBorderBottom(BorderStyle.MEDIUM_DASHED);
		style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		style2.setBorderRight(BorderStyle.MEDIUM_DASHED);
		style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
		style2.setBorderLeft(BorderStyle.MEDIUM_DASHED);
		style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		style2.setWrapText(true);
		style2.setAlignment(HorizontalAlignment.CENTER);
		style2.setVerticalAlignment(VerticalAlignment.CENTER);

		resultCell.setCellStyle(style2);
		serialNo.setCellStyle(style2);
		serialHeader.setCellStyle(style);
		headerCell.setCellStyle(style);
		
		FileOutputStream fos = new FileOutputStream(
				"D:\\dharish\\Jirastuff\\standalone\\src\\main\\src.main.java\\Files\\JiraResultSheet"+ date1 + ".xlsx");
		workbook.write(fos);
		fos.close();
		workbook.close();
	}

	
}